from rest_framework import generics
from .models import Produkt, Klient, Zamowienia, SzczegolyZamowienia
from .serializers import ProduktSerializer, KlientSerializer, ZamowieniaSerializer
from rest_framework.response import Response
from rest_framework.reverse import reverse
from django_filters import FilterSet, NumberFilter
from rest_framework import permissions

class RootApi(generics.GenericAPIView):
    name = 'root-api'
    def get(self, request, *args, **kwargs):
        return Response({
            'produkty': reverse(ProduktList.name, request=request),
            'klienci': reverse(KlientList.name, request=request),
        })


class ProduktFilter(FilterSet):
    from_price = NumberFilter(field_name='Cena', lookup_expr='gte')
    to_price = NumberFilter(field_name='Cena', lookup_expr='lte')

    class Meta:
        model = Produkt
        fields = ['from_price', 'to_price', 'Nazwa']

class ProduktList(generics.ListCreateAPIView):
    queryset = Produkt.objects.all()
    serializer_class = ProduktSerializer
    name = 'produkt-list'
    filter_class = ProduktFilter
    search_fields = ['Nazwa', 'Cena']
    ordering_fields = ['Nazwa', 'Cena']
    permission_classes = [permissions.DjangoModelPermissionsOrAnonReadOnly]

class ProduktDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Produkt.objects.all()
    serializer_class = ProduktSerializer
    name = 'produkt-detail'
    permission_classes = [permissions.DjangoModelPermissionsOrAnonReadOnly]


class KlientList(generics.ListCreateAPIView):
    queryset = Klient.objects.all()
    serializer_class = KlientSerializer
    name = 'klient-list'
    filter_fields = ['Nazwisko', 'adres']
    search_fields = ['Nazwisko', 'adres']
    ordering_fields = ['Nazwisko', 'adres']
    permission_classes = [permissions.DjangoModelPermissionsOrAnonReadOnly]

class KlientDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Klient.objects.all()
    serializer_class = KlientSerializer
    name = 'klient-detail'
    permission_classes = [permissions.DjangoModelPermissionsOrAnonReadOnly]

class ZamowieniaList(generics.ListCreateAPIView):
    queryset = Zamowienia.objects.all()
    serializer_class = ZamowieniaSerializer
    name = 'zamowienia-list'
    permission_classes = [permissions.DjangoModelPermissionsOrAnonReadOnly]

class ZamowieniaDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Zamowienia.objects.all()
    serializer_class = ZamowieniaSerializer
    name = 'zamowienia-detail'
    permission_classes = [permissions.DjangoModelPermissionsOrAnonReadOnly]