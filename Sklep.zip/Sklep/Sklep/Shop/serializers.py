from rest_framework import serializers
from .models import Produkt, Klient, Zamowienia, SzczegolyZamowienia

class ProduktSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Produkt
        fields = ['url', 'Nazwa', 'Cena', 'Opis']


class KlientSerializer(serializers.HyperlinkedModelSerializer):
    zamowienia = serializers.HyperlinkedRelatedField(many=True, read_only=True, view_name='zamowienia-list')
    class Meta:
        model = Klient
        fields = ['url' ,'Nazwisko', 'Imie', 'adres', 'telefon', 'Email', 'zamowienia']


class ZamowieniaSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Zamowienia
        fields = ['url', 'Data_zamowienia', 'Data_wyslania', 'Koszt_wysylki', 'Id_klienta']

