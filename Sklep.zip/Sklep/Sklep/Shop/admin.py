from django.contrib import admin

from .models import Produkt, Klient, Zamowienia, SzczegolyZamowienia

admin.site.register(Produkt)
admin.site.register(Klient)
admin.site.register(Zamowienia)
admin.site.register(SzczegolyZamowienia)
