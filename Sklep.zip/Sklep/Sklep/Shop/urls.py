from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('produkt/', views.ProduktList.as_view(), name= views.ProduktList.name),
    path('produkt/<int:pk>',views.ProduktDetail.as_view(), name= views.ProduktDetail.name),
    path('klient/',views.KlientList.as_view(), name=views.KlientList.name),
    path('klient/<int:pk>',views.KlientDetail.as_view(), name=views.KlientDetail.name),
    path('zamowienia/', views.ZamowieniaList.as_view(), name=views.ZamowieniaList.name),
    path('zamowienia/<int:pk>', views.ZamowieniaDetail.as_view(), name=views.ZamowieniaDetail.name),
    path('',views.RootApi.as_view(), name=views.RootApi.name),
]