from django.db import models

class Produkt(models.Model):
    Id_produktu = models.IntegerField(primary_key=True)
    Nazwa = models.CharField(max_length=70)
    Cena = models.DecimalField(decimal_places=2, max_digits=6)
    Opis = models.CharField(max_length=150)

    def __str__(self):
        return self.Nazwa



class Klient(models.Model):
    Id_klienta = models.IntegerField(primary_key=True)
    Nazwisko = models.CharField(max_length=70)
    Imie = models.CharField(max_length=70)
    adres = models.CharField(max_length=120)
    telefon = models.CharField(max_length=20)
    Email = models.EmailField()

    def __str__(self):
        return self.Email


class Zamowienia(models.Model):
    Id_zamowienia = models.IntegerField(primary_key=True)
    Data_zamowienia = models.DateField()
    Data_wyslania = models.DateField()
    Koszt_wysylki = models.DecimalField(decimal_places=2, max_digits=3)
    Id_klienta = models.ForeignKey(Klient, related_name='zamowienia', on_delete=models.CASCADE, null=True)

    def __str__(self):
        return self.Id_zamowienia

class SzczegolyZamowienia(models.Model):
    Id_zamowienia = models.ForeignKey(Zamowienia, related_name='zamowienia', on_delete=models.CASCADE, null=True)
    Id_produktu = models.ForeignKey(Produkt, related_name='produkty', on_delete=models.CASCADE, null=True)
    Ilosc = models.IntegerField()
